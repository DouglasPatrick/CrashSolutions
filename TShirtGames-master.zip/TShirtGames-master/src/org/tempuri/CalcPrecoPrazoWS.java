/**
 * CalcPrecoPrazoWS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public interface CalcPrecoPrazoWS extends javax.xml.rpc.Service {
    public java.lang.String getCalcPrecoPrazoWSSoapAddress();

    public org.tempuri.CalcPrecoPrazoWSSoap getCalcPrecoPrazoWSSoap() throws javax.xml.rpc.ServiceException;

    public org.tempuri.CalcPrecoPrazoWSSoap getCalcPrecoPrazoWSSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
